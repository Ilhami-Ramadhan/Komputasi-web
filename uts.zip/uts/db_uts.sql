-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Oct 23, 2024 at 09:04 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_uts`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` smallint(3) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `nim` varchar(30) NOT NULL,
  `email` varchar(31) NOT NULL,
  `warna` varchar(30) NOT NULL,
  `biografi` text NOT NULL,
  `judul` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `nama`, `nim`, `email`, `warna`, `biografi`, `judul`) VALUES
(1, 'Raihan Ilham Ramadhan', '2023071075', 'raihanilhamramadhan15@gmail.com', 'Hijau', 'Saya adalah mahasiswa program studi Informatika di Universitas Pembangunan Jaya. Sejak memulai pendidikan di bidang ini, saya telah memiliki ketertarikan yang mendalam terhadap teknologi dan pengembangan perangkat lunak. Saat ini, saya juga aktif sebagai asisten laboratorium di jurusan saya, di mana saya membantu rekan-rekan mahasiswa lain dalam memahami materi dan praktik di bidang informatika. Selain itu, saya terlibat dalam unit kegiatan mahasiswa Muay Thai, yang menjadi salah satu cara saya untuk tetap aktif secara fisik dan menjaga keseimbangan antara akademik dan kesehatan.\r\n\r\nDi waktu luang, saya menikmati bermain Mobile Legends, yang menjadi salah satu cara untuk bersantai dan bersenang-senang. Saya selalu berusaha untuk terus berkembang dan belajar, baik di dalam kelas maupun di luar lingkungan akademik. Tujuan saya adalah menjadi profesional di dunia teknologi informasi, dengan fokus pada pengembangan aplikasi dan solusi digital yang bermanfaat bagi masyarakat.', 'ABAOUT ME!!....');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `id` smallint(3) NOT NULL,
  `about` text NOT NULL,
  `portofolio` text NOT NULL,
  `jadwal` text NOT NULL,
  `teman` text NOT NULL,
  `judul1` varchar(15) NOT NULL,
  `judul2` varchar(15) NOT NULL,
  `judul3` varchar(15) NOT NULL,
  `judul4` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `about`, `portofolio`, `jadwal`, `teman`, `judul1`, `judul2`, `judul3`, `judul4`) VALUES
(1, 'Ingin Tau Lebih Banyak Tentang Saya Klik', 'LIhat Daftar Projek Saya Klik', 'Lihat Jadwal Saya Minggu Ini Klik', 'Ingin Lihat Teman Saya Klik', 'ABOUT ME', 'PORTOFOLIO', 'JADWAL', 'DAFTAR TEMAN');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id` smallint(3) NOT NULL,
  `senin` varchar(200) NOT NULL,
  `selasa` varchar(200) NOT NULL,
  `rabu` varchar(200) NOT NULL,
  `kamis` varchar(200) NOT NULL,
  `jumat` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id`, `senin`, `selasa`, `rabu`, `kamis`, `jumat`) VALUES
(1, '-', 'AOK', 'KOM WEB', 'MATDIS', 'DAA'),
(2, '-', 'B.INGRIS', 'DMM', '-', 'PSI'),
(3, '-', '-', 'BASDAT', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `portofolio`
--

CREATE TABLE `portofolio` (
  `id` smallint(6) NOT NULL,
  `PenjelasanDB` text NOT NULL,
  `PenjelasanWB` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `portofolio`
--

INSERT INTO `portofolio` (`id`, `PenjelasanDB`, `PenjelasanWB`) VALUES
(1, 'Ini merupakan projek pertama saya saat semester 2, di sini saya diminta membuat database mahasiswa yang table bisa langsung di ubah di web.', 'Ini merupakan projek kedua saya  saat semester 3, di sini saya diminta untuk membuat web berita dengan minimal 2 berita di dalam satu web.');

-- --------------------------------------------------------

--
-- Table structure for table `teman`
--

CREATE TABLE `teman` (
  `nim` char(10) NOT NULL,
  `nama` varchar(60) NOT NULL,
  `panggilan` varchar(15) NOT NULL,
  `prodi` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teman`
--

INSERT INTO `teman` (`nim`, `nama`, `panggilan`, `prodi`) VALUES
('2023071050', 'Satrio Dwi Ramadhan', 'Satrio', 'Inf'),
('2023071075', 'Rendi yulio', 'Rendi', 'INF'),
('2023071076', 'Ahmad Zidane Qolbin Akbar', 'Dane', 'INF'),
('2023071078', 'Leonardo', 'Leo', 'INF');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portofolio`
--
ALTER TABLE `portofolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teman`
--
ALTER TABLE `teman`
  ADD PRIMARY KEY (`nim`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
