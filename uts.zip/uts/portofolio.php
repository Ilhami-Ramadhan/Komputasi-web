<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N"
        crossorigin="anonymous">
    <style>
        body {
            background-image: url('bg-portofolio.jpg'); 
            background-size: cover; /* Agar gambar memenuhi seluruh layar */
            background-repeat: no-repeat; /* Agar gambar tidak berulang */
            color: white; /* Set warna teks menjadi putih */
        }

        .content-section {
            background-color: rgba(0, 0, 0, 0.7); /* Latar belakang semi transparan */
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .heading-section {
            text-align: center;
            margin-bottom: 30px; /* Menambah jarak di bawah judul */
        }

        .card-img-top {
            object-fit: contain; /* Mengatur gambar agar seluruh gambar terlihat */
            height: 200px; /* Mengatur tinggi gambar */
            width: 100%; /* Agar gambar memenuhi lebar kartu */
            border-top-left-radius: 8px; /* Membulatkan sudut atas kiri */
            border-top-right-radius: 8px; /* Membulatkan sudut atas kanan */
        }
    </style>
    <title>Portofolio</title>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-info" style="font-size: 1.5rem; padding: 1rem;">
    <div class="container-fluid">
        <a class="navbar-brand" href="home.php" style="font-size: 2rem;">HOME</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link" href="about.php" style="font-size: 1.5rem;">About Me</a>
                <a class="nav-link active" aria-current="page" href="portofolio.php" style="font-size: 1.5rem;">Portofolio</a>
                <a class="nav-link" href="jadwal.php" style="font-size: 1.5rem;">Jadwal</a>
                <a class="nav-link" href="teman.php" style="font-size: 1.5rem;">Daftar Teman</a>
            </div>
        </div>
    </div>
</nav>

<?php
include("koneksi.php");
// Query untuk mengambil data dari tabel "home"
$sql = "SELECT * FROM portofolio";
$hasil = mysqli_query($koneksi, $sql);

// Cek apakah query berhasil
if (!$hasil) {
    // Hentikan skrip jika query gagal
    die("Query gagal: " . mysqli_error($koneksi));
}

// Cek apakah ada data
if (mysqli_num_rows($hasil) > 0) {
    $row = mysqli_fetch_assoc($hasil); // Ambil data baris pertama jika ada
} else {
    $row = []; // Jika tidak ada data, set array kosong
}

// Menutup koneksi
mysqli_close($koneksi);
?>


<div class="container content-section">
    <div class="heading-section">
        <h2>PROJEK - PROJEK YANG SAYA BUAT</h2>
    </div>

    <div class="row">
        <div class="col-sm-6">
            <div class="card text-white bg-primary mb-3">
                <img src="DB.png" class="card-img-top" alt="Database Project Image">
                <div class="card-header">Database Projects</div>
                <div class="card-body">
                    <p class="card-text"><?= isset($row["PenjelasanDB"]) ? $row["PenjelasanDB"] : 'Tidak ada data.'; ?></p>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card text-white bg-success mb-3">
                <img src="WB.png" class="card-img-top" alt="Web Project Image">
                <div class="card-header">Web Projects</div>
                <div class="card-body">
                    <p class="card-text"><?= isset($row["PenjelasanWB"]) ? $row["PenjelasanWB"] : 'Tidak ada data.'; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>
</html>
