<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
          integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N"
          crossorigin="anonymous">
    <style>
        body {
            background-image: url('bg-dashboard.jpg');
            background-size: cover; /* Agar gambar memenuhi seluruh layar */
            background-repeat: no-repeat; /* Agar gambar tidak berulang */
            height: 100vh; /* Membuat body memenuhi tinggi viewport */
            margin: 0; /* Menghilangkan margin default */
        }
        .circle-image {
            width: 200px;         /* Atur ukuran gambar */
            height: 200px;        /* Sama seperti width agar jadi lingkaran */
            border-radius: 50%;   /* Border radius 50% untuk membuat gambar jadi lingkaran */
            object-fit: cover;    /* Menjaga proporsi gambar agar tidak terdistorsi */
            border: 5px solid #000;  /* Menambahkan border hitam di sekitar gambar */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);  /* Menambahkan bayangan di sekitar gambar */
            margin-top: 50px;     /* Geser sedikit ke bawah dari atas */
        }
        .profile-container {
            display: flex;         /* Menggunakan Flexbox */
            justify-content: center; /* Mengatur konten di tengah secara horizontal */
            align-items: flex-start; /* Mengatur konten sedikit di atas (agar tidak di tengah) */
            margin-top: 25px;
        }
        .content-section {
            margin-top: 30px; /* Memberikan jarak antar bagian */
        }
    </style>
    
    <title>Home</title>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-info" style="font-size: 1.5rem; padding: 1rem;">
    <div class="container-fluid">
        <a class="navbar-brand" href="home.php" style="font-size: 2rem;">HOME</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link" href="about.php" style="font-size: 1.5rem;">About Me</a>
                <a class="nav-link" href="portofolio.php" style="font-size: 1.5rem;">Portofolio</a>
                <a class="nav-link" href="jadwal.php" style="font-size: 1.5rem;">Jadwal</a>
                <a class="nav-link" href="teman.php" style="font-size: 1.5rem;">Daftar Teman</a>
            </div>
        </div>
    </div>
</nav>

<div class="profile-container">
    <img src="profil.jpg" alt="Foto Profil" class="circle-image">
</div>

<?php
include("koneksi.php");
// Query untuk mengambil data dari tabel "home"
$sql = "SELECT * FROM home";
$hasil = mysqli_query($koneksi, $sql);

// Cek apakah query berhasil
if (!$hasil) {
    // Hentikan skrip jika query gagal
    die("Query gagal: " . mysqli_error($koneksi));
}

// Cek apakah ada data
if (mysqli_num_rows($hasil) > 0) {
    $row = mysqli_fetch_assoc($hasil); // Ambil data baris pertama jika ada
} else {
    $row = []; // Jika tidak ada data, set array kosong
}

// Menutup koneksi
mysqli_close($koneksi);
?>

<div class="container content-section">
    <div class="row">
        <div class="col-sm-3">
            <p style="color: green;"><?= isset($row["about"]) ? $row["about"] : 'Tidak ada data.'; ?></p>
            <h3 style="color: blue;"><?= isset($row["judul1"]) ? $row["judul1"] : ''; ?></h3>
        </div>
        <div class="col-sm-3">
            <p style="color: green;"><?= isset($row["portofolio"]) ? $row["portofolio"] : 'Tidak ada data.'; ?></p>
            <h3 style="color: blue;"><?= isset($row["judul2"]) ? $row["judul2"] : ''; ?></h3>
        </div>
        <div class="col-sm-3">
            <p style="color: green;"><?= isset($row["jadwal"]) ? $row["jadwal"] : 'Tidak ada data.'; ?></p>
            <h3 style="color: blue;"><?= isset($row["judul3"]) ? $row["judul3"] : ''; ?></h3>
        </div>
        <div class="col-sm-3">
            <p style="color: green;"><?= isset($row["teman"]) ? $row["teman"] : 'Tidak ada data.'; ?></p>
            <h3 style="color: blue;"><?= isset($row["judul4"]) ? $row["judul4"] : ''; ?></h3>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>
</html>
