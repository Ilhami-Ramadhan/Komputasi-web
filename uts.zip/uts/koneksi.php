<?php

// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Informasi koneksi ke database
$serverName = "localhost";
$userName = "root";
$password = "root";
$dbName = "db_uts";

// Membuat koneksi
$koneksi = mysqli_connect($serverName, $userName, $password, $dbName);

// Cek koneksi
if (!$koneksi) {
    // Hentikan skrip jika koneksi gagal
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
