<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <style>
        body {
            background-image: url('bg-jadwal.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: #FFFFFF;
        }

        h1, label {
            color: #FFFFFF;
            margin-top: 35px;
        }

        table {
            background-color: #FFFFFF;
            color: #000000;
        }

        th, td {
            border: 1px solid #000000;
            text-align: center;
        }

        .btn-primary, .btn-warning, .btn-danger {
            font-size: 1.2rem;
        }

        .form-control {
            background-color: #333333;
            color: #FFFFFF;
            border: 1px solid #FFFFFF;
        }
    </style>
    <title>Jadwal Kuliah</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-info" style="font-size: 1.5rem; padding: 1rem;">
  <div class="container-fluid">
    <a class="navbar-brand" href="home.php" style="font-size: 2rem;">HOME</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link" href="about.php" style="font-size: 1.5rem;">About Me</a>
        <a class="nav-link" href="portofolio.php" style="font-size: 1.5rem;">Portofolio</a>
        <a class="nav-link active" aria-current="page" href="jadwal.php" style="font-size: 1.5rem;">Jadwal</a>
        <a class="nav-link" href="teman.php" style="font-size: 1.5rem;">Daftar Teman</a>
      </div>
    </div>
  </div>
</nav>

<?php
include("koneksi.php");

// Inisialisasi variabel untuk menyimpan pesan
$pesan = "";

// Tambah data jadwal
if (isset($_POST['tambah'])) {
    $id = $_POST['id']; // Ambil ID dari input
    $senin = $_POST['senin'];
    $selasa = $_POST['selasa'];
    $rabu = $_POST['rabu'];
    $kamis = $_POST['kamis'];
    $jumat = $_POST['jumat'];

    // Query untuk menambah data, menyertakan ID
    $sql = "INSERT INTO jadwal (id, senin, selasa, rabu, kamis, jumat) VALUES ('$id', '$senin', '$selasa', '$rabu', '$kamis', '$jumat')";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Jadwal berhasil ditambahkan!";
        header("Location: jadwal.php"); // Redirect agar form kembali bersih setelah submit
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Hapus data jadwal
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $sql = "DELETE FROM jadwal WHERE id = $id";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Jadwal berhasil dihapus!";
        header("Location: jadwal.php"); // Redirect setelah penghapusan
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Ubah data jadwal
if (isset($_POST['ubah'])) {
    $id = $_POST['id'];
    $senin = $_POST['senin'];
    $selasa = $_POST['selasa'];
    $rabu = $_POST['rabu'];
    $kamis = $_POST['kamis'];
    $jumat = $_POST['jumat'];

    // Query untuk mengubah data
    $sql = "UPDATE jadwal SET senin = '$senin', selasa = '$selasa', rabu = '$rabu', kamis = '$kamis', jumat = '$jumat' WHERE id = $id";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Jadwal berhasil diubah!";
        header("Location: jadwal.php"); // Redirect setelah pengubahan
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Ambil data jadwal dari database
$sql = "SELECT * FROM jadwal";
$hasil = mysqli_query($koneksi, $sql);
?>

<div class="container mt-5">
<h1 class="text-center" style="margin-top: 50px;">Jadwal Kuliah</h1>
    <?php if ($pesan): ?>
        <div class="alert alert-info"><?= $pesan ?></div>
    <?php endif; ?>
    
    <!-- Form Tambah/Ubah Jadwal -->
    <form method="POST">
        <div class="form-row">
            <div class="form-group col-md-2">
                <label>ID</label>
                <input type="number" name="id" class="form-control" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>" required>
            </div>
            <div class="form-group col-md-2">
                <label>Senin</label>
                <input type="text" name="senin" class="form-control" value="<?= isset($_GET['senin']) ? $_GET['senin'] : '' ?>" required>
            </div>
            <div class="form-group col-md-2">
                <label>Selasa</label>
                <input type="text" name="selasa" class="form-control" value="<?= isset($_GET['selasa']) ? $_GET['selasa'] : '' ?>" required>
            </div>
            <div class="form-group col-md-2">
                <label>Rabu</label>
                <input type="text" name="rabu" class="form-control" value="<?= isset($_GET['rabu']) ? $_GET['rabu'] : '' ?>" required>
            </div>
            <div class="form-group col-md-2">
                <label>Kamis</label>
                <input type="text" name="kamis" class="form-control" value="<?= isset($_GET['kamis']) ? $_GET['kamis'] : '' ?>" required>
            </div>
            <div class="form-group col-md-2">
                <label>Jumat</label>
                <input type="text" name="jumat" class="form-control" value="<?= isset($_GET['jumat']) ? $_GET['jumat'] : '' ?>" required>
            </div>
        </div>

        <?php if (isset($_GET['ubah'])): ?>
            <button type="submit" name="ubah" class="btn btn-warning">Ubah Jadwal</button>
        <?php else: ?>
            <button type="submit" name="tambah" class="btn btn-primary">Tambah Jadwal</button>
        <?php endif; ?>
    </form>

    <!-- Tabel Jadwal -->
    <table class="table table-bordered mt-5">
        <thead>
            <tr>
                <th>ID</th>
                <th>Senin</th>
                <th>Selasa</th>
                <th>Rabu</th>
                <th>Kamis</th>
                <th>Jumat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($hasil)): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['senin'] ?></td>
                <td><?= $row['selasa'] ?></td>
                <td><?= $row['rabu'] ?></td>
                <td><?= $row['kamis'] ?></td>
                <td><?= $row['jumat'] ?></td>
                <td>
                    <a href="jadwal.php?ubah=<?= $row['id'] ?>&senin=<?= $row['senin'] ?>&selasa=<?= $row['selasa'] ?>&rabu=<?= $row['rabu'] ?>&kamis=<?= $row['kamis'] ?>&jumat=<?= $row['jumat'] ?>" class="btn btn-warning btn-sm">Ubah</a>
                    <a href="jadwal.php?hapus=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc8V8QwBv9jFW5y6xkPsIvRS1xE+KCvrHj7/x8EN" crossorigin="anonymous"></script>
</body>
</html>
