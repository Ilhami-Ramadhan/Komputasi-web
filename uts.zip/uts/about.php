<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N"
        crossorigin="anonymous">
    <style>
        body {
            background-image: url('bg-about.jpg'); 
            background-size: cover; 
            background-repeat: no-repeat;
            color: white; /* Set text color globally to white for better visibility */
            
        }

        .content-section {
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .content-section p {
            margin-top: 50px;
            padding: 10px 0;
        }

        .heading-section {
            text-align: center;
            margin-bottom: 20px;
        }

        .row .col-sm-3 {
            display: flex;
            align-items: center;
        }
        
        .heading-section {
    text-align: center;
    margin-top: 50px; /* Menambahkan jarak dari navbar */
    margin-bottom: 20px;
    }
    </style>
    <title>About Me</title>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-info" style="font-size: 1.5rem; padding: 1rem;">
  <div class="container-fluid">
    <a class="navbar-brand" href="home.php" style="font-size: 2rem;">HOME</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="about.php" style="font-size: 1.5rem;">About Me</a>
        <a class="nav-link" href="portofolio.php" style="font-size: 1.5rem;">Portofolio</a>
        <a class="nav-link" href="jadwal.php" style="font-size: 1.5rem;">Jadwal</a>
        <a class="nav-link" href="teman.php" style="font-size: 1.5rem;">Daftar Teman</a>
      </div>
    </div>
  </div>
</nav>

<?php
include("koneksi.php");

// Query untuk mengambil data dari tabel "about"
$sql = "SELECT * FROM about";
$hasil = mysqli_query($koneksi, $sql);

// Cek apakah data ada
if (mysqli_num_rows($hasil) > 0) {
    $row = mysqli_fetch_assoc($hasil); // Ambil data baris pertama 
} else {
    $row = []; // Jika tidak ada data, set array kosong
}

// Menutup koneksi
mysqli_close($koneksi);
?>

<div class="container content-section">
  <div class="row justify-content-center">
    <div class="col-sm-12">
      <div class="heading-section">
      <h2 style="color: white;"><?= isset($row["judul"]) ? $row["judul"] : ''; ?></h2>
      </div>
      
      <div class="row">
        <div class="col-sm-3">
          <p><strong>Nama:</strong> <?= isset($row["nama"]) ? $row["nama"] : 'Tidak ada data.'; ?></p>
        </div>
        <div class="col-sm-2">
          <p><strong>NIM:</strong> <?= isset($row["nim"]) ? $row["nim"] : 'Tidak ada data.'; ?></p>
        </div>
        <div class="col-sm-4">
          <p><strong>Email:</strong> <?= isset($row["email"]) ? $row["email"] : 'Tidak ada data.'; ?></p>
        </div>
        <div class="col-sm-3">
          <p><strong>Warna Kesukaan:</strong> <?= isset($row["warna"]) ? $row["warna"] : 'Tidak ada data.'; ?></p>
        </div>
        <div class="col-sm-12">
        <p style="background-color: rgba(0, 0, 0, 0.7);"><strong>Biografi:</strong> <?= isset($row["biografi"]) ? $row["biografi"] : 'Tidak ada data.'; ?></p>
      </div>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>
</html>
