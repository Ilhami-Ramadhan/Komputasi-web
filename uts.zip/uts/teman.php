<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N"
        crossorigin="anonymous">
    <style>
        body {
            background-image: url('bg-teman.jpg'); 
            background-size: cover; /* Agar gambar memenuhi seluruh layar */
            background-repeat: no-repeat; /* Agar gambar tidak berulang */
            color: white; /* Mengatur warna teks umum menjadi putih */
        }
        .container {
            margin-top: 50px;
        }

        .btn-primary, .btn-warning, .btn-danger {
            font-size: 1.2rem;
        }

        .form-control {
            margin-bottom: 15px;
            background-color: rgba(255, 255, 255, 0.8); /* Warna latar belakang input untuk kontras */
            color: black; /* Mengatur warna teks input menjadi hitam untuk kontras */
        }

        /* Mengubah warna teks tabel menjadi putih */
        table {
            color: white; /* Mengatur warna teks tabel menjadi putih */
            width: 100%; /* Memastikan tabel mengisi lebar penuh */
        }
        
        th, td {
            background-color: rgba(0, 0, 0, 0.5); /* Mengatur latar belakang sel tabel */
            color: white; /* Mengatur warna teks dalam header dan sel tabel menjadi putih */
        }
        
        th {
            background-color: rgba(0, 123, 255, 0.7); /* Latar belakang header tabel */
        }
    </style>
    <title>About Me</title>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-info" style="font-size: 1.5rem; padding: 1rem;">
  <div class="container-fluid">
    <a class="navbar-brand" href="home.php" style="font-size: 2rem;">HOME</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link" href="about.php" style="font-size: 1.5rem;">About Me</a>
        <a class="nav-link" href="portofolio.php" style="font-size: 1.5rem;">Portofolio</a>
        <a class="nav-link" href="jadwal.php" style="font-size: 1.5rem;">Jadwal</a>
        <a class="nav-link active"  aria-current="page" href="teman.php" style="font-size: 1.5rem;">Daftar Teman</a>
      </div>
    </div>
  </div>
</nav>

<?php
include("koneksi.php");
// Inisialisasi variabel untuk menyimpan pesan
$pesan = "";

// Tambah data teman
if (isset($_POST['tambah'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $panggilan = $_POST['panggilan'];
    $prodi = $_POST['prodi'];

    // Query untuk menambah data
    $sql = "INSERT INTO teman (nim, nama, panggilan, prodi) VALUES ('$nim', '$nama', '$panggilan', '$prodi')";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Teman berhasil ditambahkan!";
        header("Location: teman.php"); // Redirect agar form kembali bersih setelah submit
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Hapus data teman
if (isset($_GET['hapus'])) {
    $nim = $_GET['hapus'];
    $sql = "DELETE FROM teman WHERE nim = '$nim'";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Teman berhasil dihapus!";
        header("Location: teman.php"); // Redirect setelah penghapusan
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Ubah data teman
if (isset($_POST['ubah'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $panggilan = $_POST['panggilan'];
    $prodi = $_POST['prodi'];

    // Query untuk mengubah data
    $sql = "UPDATE teman SET nama = '$nama', panggilan = '$panggilan', prodi = '$prodi' WHERE nim = '$nim'";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Teman berhasil diubah!";
        header("Location: teman.php"); // Redirect setelah pengubahan
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Ambil data teman dari database
$sql = "SELECT * FROM teman";
$hasil = mysqli_query($koneksi, $sql);
?>

<div class="container">
    <h1 class="text-center">Daftar Teman</h1>
    <?php if ($pesan): ?>
        <div class="alert alert-info"><?= $pesan ?></div>
    <?php endif; ?>

    <!-- Form Tambah/Ubah Teman -->
    <form method="POST">
        <input type="hidden" name="nim" value="<?= isset($_GET['ubah']) ? $_GET['ubah'] : '' ?>">
        <div class="form-group">
            <label>NIM</label>
            <input type="text" name="nim" class="form-control" value="<?= isset($_GET['nim']) ? $_GET['nim'] : '' ?>" required>
        </div>
        <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="<?= isset($_GET['nama']) ? $_GET['nama'] : '' ?>" required>
        </div>
        <div class="form-group">
            <label>Panggilan</label>
            <input type="text" name="panggilan" class="form-control" value="<?= isset($_GET['panggilan']) ? $_GET['panggilan'] : '' ?>" required>
        </div>
        <div class="form-group">
            <label>Prodi</label>
            <input type="text" name="prodi" class="form-control" value="<?= isset($_GET['prodi']) ? $_GET['prodi'] : '' ?>" required>
        </div>

        <?php if (isset($_GET['ubah'])): ?>
            <button type="submit" name="ubah" class="btn btn-warning">Ubah Teman</button>
        <?php else: ?>
            <button type="submit" name="tambah" class="btn btn-primary">Tambah Teman</button>
        <?php endif; ?>
    </form>

    <!-- Tabel Teman -->
    <table class="table table-bordered mt-5">
        <thead>
            <tr>
                <th>NIM</th>
                <th>Nama</th>
                <th>Panggilan</th>
                <th>Prodi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($hasil)): ?>
            <tr>
                <td><?= $row['nim'] ?></td>
                <td><?= $row['nama'] ?></td>
                <td><?= $row['panggilan'] ?></td>
                <td><?= $row['prodi'] ?></td>
                <td>
                    <a href="teman.php?ubah=<?= $row['nim'] ?>&nim=<?= $row['nim'] ?>&nama=<?= $row['nama'] ?>&panggilan=<?= $row['panggilan'] ?>&prodi=<?= $row['prodi'] ?>" class="btn btn-warning btn-sm">Ubah</a>
                    <a href="teman.php?hapus=<?= $row['nim'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>
</html>
